﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using Klasa; 

namespace ServerApp3
{
    public partial class Form1 : Form
    {
        private TcpListener tcpServer;
        private UdpClient udpSenzori, udpVideo;
        private Thread tcpThread, udpSenzorThread, udpVideoThread;
        private bool radi = true;
        private Random rng = new Random();
        private List<TcpClient> klijenti = new List<TcpClient>();
        private bool sendSensorData = false;
        private readonly object klijentiLock = new object();

        public Form1()
        {
            InitializeComponent();
        }

        private void btnPokreniServer_Click(object sender, EventArgs e)
        {
            btnPokreniServer.Enabled = false;
            PokreniServise();
        }

        private void PokreniServise()
        {
            tcpServer = new TcpListener(IPAddress.Any, 8889);
            tcpThread = new Thread(SlusajTCP);
            tcpThread.Start();

            udpSenzori = new UdpClient();
            udpSenzori.EnableBroadcast = true;
            udpSenzorThread = new Thread(SlusajUDP_Senzori);
            udpSenzorThread.Start();

            udpVideo = new UdpClient(10000);
            udpVideoThread = new Thread(SlusajVideoZahtjeve);
            udpVideoThread.Start();

            listBox1.Items.Add($"[{DateTime.Now:HH:mm:ss}] Server pokrenut");
        }

        private void SlusajTCP()
        {
            tcpServer.Start();
            while (radi)
            {
                TcpClient klijent = tcpServer.AcceptTcpClient();
                lock (klijentiLock)
                {
                    klijenti.Add(klijent);
                    if (klijenti.Count == 1)
                        sendSensorData = true;
                }
                new Thread(() => ObradiKlijenta(klijent)).Start();
                Invoke((MethodInvoker)delegate {
                    listBox1.Items.Add($"[{DateTime.Now:HH:mm:ss}] Novi klijent spojen");
                });
            }
        }

        private void ObradiKlijenta(TcpClient klijent)
        {
            try
            {
                NetworkStream tok = klijent.GetStream();
                byte[] buffer = new byte[1024];
                while (radi)
                {
                    int procitano = tok.Read(buffer, 0, buffer.Length);
                    if (procitano == 0) break;
                    string komanda = Encoding.UTF8.GetString(buffer, 0, procitano);
                    ObradiKomandu(komanda);
                }
            }
            catch { }
            finally
            {
                lock (klijentiLock)
                {
                    klijenti.Remove(klijent);
                    if (klijenti.Count == 0)
                        sendSensorData = false;
                }
                klijent.Close();
                Invoke((MethodInvoker)delegate {
                    listBox1.Items.Add($"[{DateTime.Now:HH:mm:ss}] Klijent odspojen");
                });
            }
        }

        private void ObradiKomandu(string komanda)
        {
            Invoke((MethodInvoker)delegate
            {
                listBox1.Items.Add($"[{DateTime.Now:HH:mm:ss}] Primljena naredba: {komanda}");
                switch (komanda)
                {
                    case "OTVORI_VRATA":
                        lblStatusVrata.Text = "Vrata: OTVORENA";
                        lblStatusVrata.ForeColor = Color.Green;
                        PosaljiSvima("VRATA_OTVORENA");
                        break;
                    case "ZATVORI_VRATA":
                        lblStatusVrata.Text = "Vrata: ZATVORENA";
                        lblStatusVrata.ForeColor = Color.Red;
                        PosaljiSvima("VRATA_ZATVORENA");
                        break;
                }
            });
        }

        private void SlusajUDP_Senzori()
        {
            BinaryFormatter formatter = new BinaryFormatter();
            IPEndPoint ep = new IPEndPoint(IPAddress.Broadcast, 9999);

            while (radi)
            {
                if (sendSensorData)
                {
                    var podaci = new PodaciSenzora
                    {
                        Temperatura = rng.Next(18, 30),
                        Vlaznost = rng.Next(30, 70)
                    };

                    Invoke((MethodInvoker)delegate
                    {
                        lblTemperatura.Text = $"Temperatura: {podaci.Temperatura}°C";
                        lblVlaznost.Text = $"Vlažnost: {podaci.Vlaznost}%";
                    });

                    using (MemoryStream ms = new MemoryStream())
                    {
                        formatter.Serialize(ms, podaci);
                        byte[] buffer = ms.ToArray();
                        udpSenzori.Send(buffer, buffer.Length, ep);
                        Invoke((MethodInvoker)delegate
                        {
                            listBox1.Items.Add($"[{DateTime.Now:HH:mm:ss}] Poslani senzori: {podaci.Temperatura}°C, {podaci.Vlaznost}%");
                        });
                    }
                }
                Thread.Sleep(5000);
            }
        }

        private void SlusajVideoZahtjeve()
        {
            IPEndPoint klijentEP = new IPEndPoint(IPAddress.Any, 0);
            while (radi)
            {
                byte[] zahtjev = udpVideo.Receive(ref klijentEP);
                string komanda = Encoding.UTF8.GetString(zahtjev);
                if (komanda == "POKRENI_VIDEO")
                {
                    Invoke((MethodInvoker)delegate
                    {
                        listBox1.Items.Add($"[{DateTime.Now:HH:mm:ss}] Video zahtjev od {klijentEP.Address}");
                    });
                    SaljiVideo(klijentEP);
                }
            }
        }

        private void SaljiVideo(IPEndPoint klijentEP)
        {
            string videoPath = "video.mp4";
            if (!File.Exists(videoPath))
            {
                Invoke((MethodInvoker)delegate
                {
                    listBox1.Items.Add($"[{DateTime.Now:HH:mm:ss}] Video file nije pronađen!");
                });
                return;
            }

            try
            {
                using (FileStream fs = new FileStream(videoPath, FileMode.Open))
                {
                    byte[] buffer = new byte[8192];
                    int bytesRead;
                    while ((bytesRead = fs.Read(buffer, 0, buffer.Length)) > 0)
                    {
                        
                        udpVideo.Send(buffer, bytesRead, klijentEP);
                        Thread.Sleep(10); 
                    }
                }
                Invoke((MethodInvoker)delegate
                {
                    listBox1.Items.Add($"[{DateTime.Now:HH:mm:ss}] Video poslan");
                });
            }
            catch (Exception ex)
            {
                Invoke((MethodInvoker)delegate
                {
                    listBox1.Items.Add($"[{DateTime.Now:HH:mm:ss}] Greška pri slanju videa: {ex.Message}");
                });
            }
        }


        private void PosaljiSvima(string poruka)
        {
            byte[] buffer = Encoding.UTF8.GetBytes(poruka);
            lock (klijentiLock)
            {
                foreach (var klijent in klijenti)
                {
                    if (klijent.Connected)
                        klijent.GetStream().Write(buffer, 0, buffer.Length);
                }
            }
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            radi = false;
            tcpServer?.Stop();
            udpSenzori?.Close();
            udpVideo?.Close();
            base.OnFormClosing(e);
        }
    }
}
