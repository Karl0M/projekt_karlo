﻿namespace ServerApp3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnPokreniServer = new System.Windows.Forms.Button();
            this.lblTemperatura = new System.Windows.Forms.Label();
            this.lblVlaznost = new System.Windows.Forms.Label();
            this.lblStatusVrata = new System.Windows.Forms.Label();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // btnPokreniServer
            // 
            this.btnPokreniServer.Location = new System.Drawing.Point(106, 70);
            this.btnPokreniServer.Name = "btnPokreniServer";
            this.btnPokreniServer.Size = new System.Drawing.Size(115, 23);
            this.btnPokreniServer.TabIndex = 0;
            this.btnPokreniServer.Text = "Pokreni server";
            this.btnPokreniServer.UseVisualStyleBackColor = true;
            this.btnPokreniServer.Click += new System.EventHandler(this.btnPokreniServer_Click);
            // 
            // lblTemperatura
            // 
            this.lblTemperatura.AutoSize = true;
            this.lblTemperatura.Location = new System.Drawing.Point(139, 198);
            this.lblTemperatura.Name = "lblTemperatura";
            this.lblTemperatura.Size = new System.Drawing.Size(35, 13);
            this.lblTemperatura.TabIndex = 1;
            this.lblTemperatura.Text = "label1";
            // 
            // lblVlaznost
            // 
            this.lblVlaznost.AutoSize = true;
            this.lblVlaznost.Location = new System.Drawing.Point(142, 241);
            this.lblVlaznost.Name = "lblVlaznost";
            this.lblVlaznost.Size = new System.Drawing.Size(35, 13);
            this.lblVlaznost.TabIndex = 2;
            this.lblVlaznost.Text = "label2";
            // 
            // lblStatusVrata
            // 
            this.lblStatusVrata.AutoSize = true;
            this.lblStatusVrata.Location = new System.Drawing.Point(145, 325);
            this.lblStatusVrata.Name = "lblStatusVrata";
            this.lblStatusVrata.Size = new System.Drawing.Size(35, 13);
            this.lblStatusVrata.TabIndex = 3;
            this.lblStatusVrata.Text = "label3";
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(478, 212);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(254, 199);
            this.listBox1.TabIndex = 4;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.lblStatusVrata);
            this.Controls.Add(this.lblVlaznost);
            this.Controls.Add(this.lblTemperatura);
            this.Controls.Add(this.btnPokreniServer);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnPokreniServer;
        private System.Windows.Forms.Label lblTemperatura;
        private System.Windows.Forms.Label lblVlaznost;
        private System.Windows.Forms.Label lblStatusVrata;
        private System.Windows.Forms.ListBox listBox1;
    }
}

