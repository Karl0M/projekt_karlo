﻿using System;

namespace Klasa
{
    [Serializable]
    public class PodaciSenzora
    {
        public int Temperatura { get; set; }
        public int Vlaznost { get; set; }
    }

    public enum Naredbe
    {
        OtvoriVrata,
        ZatvoriVrata,
        PokreniVideo,
        ZaustaviVideo
    }
}
